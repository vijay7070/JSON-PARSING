//
//  SecondViewController.h
//  JSONPARSING
//
//  Created by Student P_02 on 28/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController{
    NSArray *array;
}
@property (weak, nonatomic) IBOutlet UIImageView *img2_vw;
@property (weak, nonatomic) IBOutlet UILabel *Author2lbl;
@property (weak, nonatomic) IBOutlet UITextView *title_txt;
@property (weak, nonatomic) IBOutlet UITextView *descrip_txt;
@property (weak, nonatomic) IBOutlet UILabel *publishedlbl;
@property(strong,nonatomic)NSString *titlestr;
@property(strong,nonatomic)NSString *author2str;
@property(strong,nonatomic)NSString *descripstr;
@property(strong,nonatomic)NSString *publishedstr;
@property(strong,nonatomic)NSString *imagestr;
@property(strong,nonatomic)NSString *webstr;

- (IBAction)webnews:(id)sender;


@end
