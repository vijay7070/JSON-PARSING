//
//  ViewController.m
//  JSONPARSING
//
//  Created by Student P_02 on 28/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "ViewController.h"
#import "JSONTableViewCell.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self parsedata:@"https://newsapi.org/v1/articles?source=techcrunch&apiKey=efe99de73d1d49608eb3d4e87c536b26"];
    

}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return array.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *str=@"JSONTableViewCell";
    JSONTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"JSONTableViewCell"];
    if (cell==nil) {
        cell=[[JSONTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
    }
    NSDictionary *dict=[array objectAtIndex:indexPath.row];
    cell.Authornamelbl.text=[dict valueForKey:@"author"];
    NSString *imgstr=[dict valueForKey:@"urlToImage"];
    [cell.img_vw  setImageWithURL:[NSURL URLWithString:imgstr]
                   placeholderImage:[UIImage imageNamed:@"images.png"]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    SecondViewController *obj=[self.storyboard instantiateViewControllerWithIdentifier:@"SecondViewController"];
    
    [self.navigationController pushViewController:obj animated:YES];
    NSDictionary *dict=[array objectAtIndex:indexPath.row];
    obj.titlestr=[dict valueForKey:@"title"];
    obj.descripstr=[dict valueForKey:@"description"];
    obj.publishedstr=[dict valueForKey:@"publishedAt"];
    obj.author2str=[dict valueForKey:@"author"];
    obj.imagestr=[dict valueForKey:@"urlToImage"];
    obj.webstr=[dict valueForKey:@"url"];
    
 //   NSLog(@"===========%@",tvc.strurl);
    
    
  /*  NSDictionary *dict=[array objectAtIndex:indexPath.row];
    obj.title_txt.text=[dict valueForKey:@"author"];
    NSString *imgstr=[dict valueForKey:@"urlToImage"];
    [obj.img2_vw setImageWithURL:[NSURL URLWithString:imgstr]
                placeholderImage:[UIImage imageNamed:@"images.png"]];
    */
    
    
}
-(void)parsedata:(NSString *)str{
    NSURL *url=[NSURL URLWithString:str];
    NSURLSession *session=[NSURLSession sharedSession];
    NSURLSessionDataTask *datatask=[session dataTaskWithURL:url completionHandler:^(NSData *data,NSURLResponse *response,NSError *error){
        NSLog(@"%@",data);
        
        if (!error) {
            NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
            array=[dict valueForKey:@"articles"];
            NSLog(@"%@",array);
            dispatch_async(dispatch_get_main_queue(),^{
               
                _tbl_vw.delegate=self;
                _tbl_vw.dataSource=self;
                [_tbl_vw reloadData];
            });
        }
    }];
    
    [datatask resume];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
