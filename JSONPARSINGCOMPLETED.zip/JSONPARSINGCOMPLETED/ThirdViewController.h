//
//  ThirdViewController.h
//  JSONPARSING
//
//  Created by Student P_02 on 28/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController<UIWebViewDelegate>{
    NSArray *array;
}
@property (weak, nonatomic) IBOutlet UIWebView *webview;

@property(strong,nonatomic)NSString *strurl;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *act_indi;

@end
