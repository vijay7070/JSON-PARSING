//
//  SecondViewController.m
//  JSONPARSING
//
//  Created by Student P_02 on 28/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "SecondViewController.h"
#import "ViewController.h"
#import "JSONTableViewCell.h"
#import "ThirdViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _title_txt.text=_titlestr;
    _Author2lbl.text=_author2str;
    _descrip_txt.text=_descripstr;
    _publishedlbl.text=_publishedstr;
    
    [_img2_vw setImageWithURL:[NSURL URLWithString:_imagestr]
             placeholderImage:[UIImage imageNamed:@"images.png"]];
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)webnews:(id)sender {
    ThirdViewController *tvc=[self.storyboard instantiateViewControllerWithIdentifier:@"ThirdViewController"];
    [self.navigationController pushViewController:tvc animated:YES];
    NSLog(@"%@",_webstr);
    tvc.strurl=_webstr;
}
@end
