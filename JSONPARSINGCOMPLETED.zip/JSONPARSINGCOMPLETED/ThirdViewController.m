//
//  ThirdViewController.m
//  JSONPARSING
//
//  Created by Student P_02 on 28/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "ThirdViewController.h"
#import "SecondViewController.h"
#import "ViewController.h"
@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
   
    NSURL *url=[NSURL URLWithString:_strurl];
    NSURLRequest *req=[NSURLRequest requestWithURL:url];
    _webview.delegate=self;
    [_webview loadRequest:req];
    
    
    // Do any additional setup after loading the view.
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSLog(@"%@",request);
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [_act_indi startAnimating];
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [_act_indi stopAnimating];
    _act_indi.hidden=YES;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    NSLog(@"%@",error.localizedDescription);
    [_act_indi stopAnimating];
    _act_indi.hidden=YES;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
