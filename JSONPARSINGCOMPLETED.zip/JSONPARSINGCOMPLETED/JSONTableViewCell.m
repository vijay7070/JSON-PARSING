//
//  JSONTableViewCell.m
//  JSONPARSING
//
//  Created by Student P_02 on 28/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "JSONTableViewCell.h"

@implementation JSONTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
